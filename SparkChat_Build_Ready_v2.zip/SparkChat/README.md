# Spark Chat — Build-Ready Android Project

This is the Android build project for Spark Chat.

## Easiest way to build the APK (GitHub Actions)

1. Create a new GitHub repository.
2. Upload the **contents of this SparkChat folder** to the repository root (keep the `.github/workflows/build-apk.yml` file).
3. Open the repository on GitHub.
4. Tap **Actions** → **Build Spark Chat APK** → **Run workflow**.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run and download the **SparkChat-debug-apk** artifact.
7. Extract the artifact and install `app-debug.apk` on your Android phone.

The workflow installs JDK 17 and Gradle 8.10 automatically, so you do not need to install Gradle on the device.

## Android Studio

Open the `SparkChat` folder in Android Studio. Let Gradle sync, then choose:
**Build → Build APK(s)**.

The debug APK will be created at:
`app/build/outputs/apk/debug/app-debug.apk`

## Important

This project is a local Android prototype. Features that require a real backend (such as real SMS verification, phone-to-phone messaging, push notifications, WebRTC calls, server accounts, and Play Billing) still need their production services connected. The APK build itself is configured and the GitHub Actions workflow is included.

# Spark Chat demo: no custom ProGuard rules required.

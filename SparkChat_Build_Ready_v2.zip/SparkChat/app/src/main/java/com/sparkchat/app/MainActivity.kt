package com.sparkchat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val SparkBlue = Color(0xFF1769FF)
private val SparkLight = Color(0xFFF4F7FF)

data class Chat(val name: String, val message: String, val time: String, val unread: Int = 0)
data class StatusItem(val name: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SparkChatApp() }
    }
}

@Composable
fun SparkChatApp() {
    var registered by remember { mutableStateOf(false) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = SparkBlue,
            background = Color.White,
            surface = Color.White
        )
    ) {
        if (!registered) {
            RegisterScreen { registered = true }
        } else {
            HomeScreen()
        }
    }
}

@Composable
fun RegisterScreen(onDone: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier.size(86.dp).background(SparkBlue, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Bolt, null, tint = Color.White, modifier = Modifier.size(48.dp))
            }
            Spacer(Modifier.height(18.dp))
            Text("Spark Chat", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = SparkBlue)
            Text("Simple. Fast. Connected.", color = Color.Gray)
            Spacer(Modifier.height(36.dp))
            OutlinedTextField(name, { name = it }, label = { Text("Full name") }, singleLine = true)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(phone, { phone = it }, label = { Text("Phone number") }, singleLine = true)
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onDone,
                enabled = name.isNotBlank() && phone.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Continue") }
            Spacer(Modifier.height(12.dp))
            Text(
                "Demo registration — connect SMS verification before production use.",
                color = Color.Gray, fontSize = 12.sp
            )
        }
    }
}

@Composable
fun HomeScreen() {
    var tab by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }

    if (showSettings) {
        SettingsScreen(onBack = { showSettings = false })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Spark Chat", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = {}) { Icon(Icons.Default.Search, "Search") }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.MoreVert, "More") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf(
                    Icons.Default.Chat to "Chats",
                    Icons.Default.Circle to "Updates",
                    Icons.Default.Groups to "Communities",
                    Icons.Default.Call to "Calls"
                ).forEachIndexed { i, pair ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(pair.first, pair.second) },
                        label = { Text(pair.second) }
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {}, containerColor = SparkBlue, contentColor = Color.White) {
                Icon(if (tab == 0) Icons.Default.Chat else Icons.Default.Add, "New")
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> ChatsScreen()
                1 -> UpdatesScreen()
                2 -> CommunitiesScreen()
                3 -> CallsScreen()
            }
        }
    }
}

@Composable
fun ChatsScreen() {
    val chats = listOf(
        Chat("Amaka", "Are you coming today?", "7:42 PM", 2),
        Chat("Henry", "Voice message", "6:18 PM"),
        Chat("Spark Chat Team", "Welcome to Spark Chat!", "Yesterday"),
        Chat("Chidinma", "See you tomorrow", "Yesterday"),
        Chat("Moses", "Photo", "Mon")
    )
    LazyColumn {
        items(chats) { chat ->
            Row(
                Modifier.fillMaxWidth().clickable { }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(chat.name)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(chat.name, fontWeight = FontWeight.SemiBold)
                    Text(chat.message, color = Color.Gray, maxLines = 1)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(chat.time, color = Color.Gray, fontSize = 12.sp)
                    if (chat.unread > 0) {
                        Spacer(Modifier.height(4.dp))
                        Box(Modifier.size(22.dp).background(SparkBlue, CircleShape), contentAlignment = Alignment.Center) {
                            Text("${chat.unread}", color = Color.White, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UpdatesScreen() {
    var selected by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp)) {
            FilterChip(selected == 0, { selected = 0 }, label = { Text("Status") })
            Spacer(Modifier.width(8.dp))
            FilterChip(selected == 1, { selected = 1 }, label = { Text("Channels") })
        }
        if (selected == 0) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).background(SparkBlue, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Add, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("My status", fontWeight = FontWeight.Bold)
                    Text("Tap to add a status", color = Color.Gray)
                }
            }
            Text("Recent updates", fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
            listOf("Amaka", "Chidinma", "Henry").forEach {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(it, outlined = true)
                    Spacer(Modifier.width(12.dp))
                    Text(it, fontWeight = FontWeight.Medium)
                }
            }
        } else {
            Text("Channels", fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(16.dp))
            listOf("Spark Chat Official", "Nollywood Creators", "Naija Football").forEach {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(it)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(it, fontWeight = FontWeight.SemiBold)
                        Text("Latest channel update", color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun CommunitiesScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Communities", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Bring related groups together in one place.", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Create community") }
        Spacer(Modifier.height(16.dp))
        Text("Your communities", fontWeight = FontWeight.Bold)
        listOf("Spark Creators", "Arochukwu Community").forEach {
            ListItem(
                headlineContent = { Text(it) },
                supportingContent = { Text("Community") },
                leadingContent = { Avatar(it) }
            )
        }
    }
}

@Composable
fun CallsScreen() {
    Column(Modifier.fillMaxSize()) {
        ListItem(
            headlineContent = { Text("Create call link") },
            supportingContent = { Text("Share a link for a Spark Chat call") },
            leadingContent = { Icon(Icons.Default.Link, null) },
            modifier = Modifier.clickable { }
        )
        Divider()
        listOf("Amaka", "Henry", "Chidinma").forEach {
            ListItem(
                headlineContent = { Text(it) },
                supportingContent = { Text("Tap to call") },
                leadingContent = { Avatar(it) },
                trailingContent = {
                    Row {
                        IconButton(onClick = {}) { Icon(Icons.Default.Call, "Voice call") }
                        IconButton(onClick = {}) { Icon(Icons.Default.Videocam, "Video call") }
                    }
                }
            )
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }
            )
        }
    ) { padding ->
        LazyColumn(Modifier.padding(padding)) {
            item {
                ListItem(
                    headlineContent = { Text("Christian Okafor", fontWeight = FontWeight.Bold) },
                    supportingContent = { Text("Simple. Fast. Connected.") },
                    leadingContent = { Avatar("Christian") }
                )
                Divider()
            }
            item { SettingRow(Icons.Default.Key, "Account", "Security, passkeys and verification") }
            item { SettingRow(Icons.Default.Lock, "Privacy", "Last seen, profile photo and status") }
            item { SettingRow(Icons.Default.Notifications, "Notifications", "Messages, groups and calls") }
            item { SettingRow(Icons.Default.Chat, "Chats", "Theme, font size and media visibility") }
            item { SettingRow(Icons.Default.Storage, "Storage and data", "Network usage and storage") }
            item { SettingRow(Icons.Default.Devices, "Linked devices", "Connect Spark Chat to another device") }
            item { SettingRow(Icons.Default.Help, "Help", "Support and app information") }
            item {
                Spacer(Modifier.height(20.dp))
                Text("Owner / Admin", color = SparkBlue, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
            }
            item { SettingRow(Icons.Default.AdminPanelSettings, "Owner panel", "Demo panel — secure this server-side before production") }
        }
    }
}

@Composable
fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle) },
        leadingContent = { Icon(icon, null, tint = SparkBlue) },
        modifier = Modifier.clickable { }
    )
}

@Composable
fun Avatar(name: String, outlined: Boolean = false) {
    val initial = name.trim().firstOrNull()?.uppercase() ?: "S"
    Box(
        Modifier.size(50.dp).background(
            if (outlined) SparkLight else SparkBlue, CircleShape
        ),
        contentAlignment = Alignment.Center
    ) {
        Text(initial, color = if (outlined) SparkBlue else Color.White, fontWeight = FontWeight.Bold)
    }
}

# Spark Chat Android Project

This project wraps the Firebase-connected Spark Chat web app in an Android WebView.

## Build
Open this folder in Android Studio and build:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The generated debug APK will be under:
app/build/outputs/apk/debug/

## Firebase
The included `app/src/main/assets/index.html` is the uploaded Spark Chat Firebase-connected web app. It contains the Firebase Web configuration supplied for project `spark-chat-8623e`.

## Important
This is an Android project, not a prebuilt APK. A production release still needs Android signing, testing, and any native integrations (push notifications, background calls, etc.) required by the final app.

## Online group chat (Firebase)
This version adds Firestore-backed groups with real-time messages and 6-character invite codes.

Before testing online groups, publish the rules in `FIRESTORE_RULES_GROUPS.txt` in Firebase Console → Firestore Database → Rules.

Test flow:
1. Open Spark Chat on phone A and sign in through the Online Chat/Firebase area with Phone Authentication.
2. Create a normal group, open Group info, then tap **Connect group to Firebase**.
3. Copy the 6-character invite code shown in Group info.
4. On phone B, sign in with a different phone number, open Groups, tap **Join online group**, and enter the code.
5. Open the group and send messages. Messages are stored in `groups/{groupId}/messages` and appear in real time on both phones.

This prototype uses Firebase client-side authentication and Firestore. Production deployment should add stronger role checks, moderation, abuse controls, media storage rules, push notifications, and backend validation.

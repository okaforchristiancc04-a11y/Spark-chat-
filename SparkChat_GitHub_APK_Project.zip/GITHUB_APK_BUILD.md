# Spark Chat — GitHub APK Build

1. Upload the contents of this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build Spark Chat APK**.
4. Tap **Run workflow**.
5. Wait for the workflow to finish.
6. Open the completed workflow run and download the artifact named **SparkChat-debug-apk**.
7. Extract the downloaded artifact and install `app-debug.apk` on Android.

This produces a debug APK for testing. A signed release APK/AAB for Google Play requires a release signing key and Play Console setup.

# Spark Chat Android Project

This project wraps the Firebase-connected Spark Chat web app in an Android WebView.

## Build
Open this folder in Android Studio and build:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The generated debug APK will be under:
app/build/outputs/apk/debug/

## Firebase
The included `app/src/main/assets/index.html` is the uploaded Spark Chat Firebase-connected web app. It contains the Firebase Web configuration supplied for project `spark-chat-8623e`.

## Important
This is an Android project, not a prebuilt APK. A production release still needs Android signing, testing, and any native integrations (push notifications, background calls, etc.) required by the final app.
